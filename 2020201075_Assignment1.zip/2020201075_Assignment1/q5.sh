#!/bin/bash

read test;
test1=${test,,}
pal=$(echo $test1 | rev)
if [ $test1 = $pal ]
then
   echo "Yes"
else
   echo "No"
fi
