# !/bin/bash 
read var 
res=`echo $var | tr -s "()" " "`
res=`echo $res | sed -e 's/^[[:space:]]*//'`
echo "($res)"
