#!/bin/bash

read -p ": " varname

ps -au | awk '{print $2}'| grep -v "PID" > pid.txt

count=$( wc -l < pid.txt )

if [ $varname -lt $count ]
then
let x=$varname+1
head -$x pid.txt
else
varname=$count
echo "input exceeded the total pids"
echo $varname
fi
