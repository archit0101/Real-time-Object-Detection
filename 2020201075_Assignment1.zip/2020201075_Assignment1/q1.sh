#!/bin/bash


#a.
mkdir Assignment1
cd Assignment1

#b.
touch lab{1..5}.txt

#c
ls *.txt | xargs -I {} bash -c 'mv "$1" "${1%.txt}.c"' -- {}


#d.
ls -laSh -r


#e.
find ~ -maxdepth 2


#f.
ls -d "$PWD"/* | grep ".txt"
