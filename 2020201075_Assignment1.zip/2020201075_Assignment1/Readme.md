# Assignment 1
### Q1 :
In this question I used `xargs` and pipe command to change the extension of `.txt` file to `.c` file. In last part of this question, I created few `test.text` files to print output for the last command

### Q2 :
In this question, I used `compgen` command to fetch all existing commands and store them in a file named `fetch.txt` and then I sort all commands to equate with the given input (which is also in sorted order). At the end I'm removing `fetch.txt` file.

### Q3 :
I used `~/.bash_history` file to fetch history of all commands.
Then used `awk` command to get the desired output and then removed the `.txt`
file using `rm` command.

### Q4 :
I used `tr` command to replace `(` `)` with an empty space and store the result in string `s`.This was giving space in the start and end of the string `s` sp used `sed` command to remove that space. Further I used `SED` for removing spaces between small brackets and numbers.

### Q5:
First I converted the string into lowercase , in case if the input is in uppercase using  `${s,,}` where `s` is the input. Then I reversed the string using `rev` command. Then checked whether the reverse and the original string are same or not. If they are same then string is pallindrome otherwise not.

### Q6:
I have stored the command line input in an array named `arr`. Then have done the product of all the numbers from 2nd input to the last input, then took its power with the 1st input which will give the final result.

### Q7:
Used `ps` command to get all the running process.

### Q8:
used the `crontab` command which will execute the file that is provided by the user in command line. If the content of the file is valid then it will return `0`, then print `Yes` otherwise `No`.

## Q9:
I have taken the input and then count the digits in the input excluding the space using `tr`.

### Q10:
I have taken the input of operator and the total no. of operands that the user will enter. Then i took the input of all the operands.
Then checked for the operator and then performed all the calculations on all the operands using `while` loop and at the end print the result with 4 precision.