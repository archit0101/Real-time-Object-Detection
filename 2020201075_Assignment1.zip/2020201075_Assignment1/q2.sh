#!/bin/bash
read -p "Enter input string:" ip
compgen -c > fetch.txt
c=$(echo "$ip")
c=`echo $c | grep -o . | sort |tr -d "\n"`
change=0
for cmm in $(cat fetch.txt);
do
 if [ ${#c} -ne ${#cmm} ]
 then continue
 else
  res=`echo $cmm | grep -o . | sort |tr -d "\n"`
   if [ $res == $c ]
   then
     echo Yes
     change=1
     break
   fi
 fi
done
final=0
if [ $change -eq $final ]
then
 echo No
fi
