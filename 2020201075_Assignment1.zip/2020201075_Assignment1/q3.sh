#!/bin/bash
cat ~/.bash_history | tail -n 10 | awk 'BEGIN {FS="[ \t]+|\\|"} {print $1 "" $2}' | sort | uniq -c | sort -nr | awk '{print $2 " " $1}'
