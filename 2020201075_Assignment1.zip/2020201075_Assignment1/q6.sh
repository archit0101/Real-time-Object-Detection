#!/bin/bash
power=1
for var in "$@"
do
power=`echo "$var"*"$power" | bc`
done
power=`echo "$power"/"$1" | bc`
echo "$1"^"$power" | bc
