#!/bin/bash

read operat
read num

i=0
a=()

while [ $i -lt $num ]
do
    read v
    a[$i]=$v
    i=$(($i+1))
done

res=0
if [[ $operat = "*" ]]
then
        j=0
        res=1
        while [ $j -lt $num ]
        do 
            res=$(($res*${a[$j]}))
            j=$(($j+1))
        done
    
elif [[ $operat = "+" ]]
then   
        j=0
        res=0
        while [ $j -lt $num ]
        do
            res=$(($res+${a[$j]}))
            j=$(($j+1))
        done

elif [[ $operat = "/" ]]
    then   
        j=0
        res=${a[$j]}
        j=`expr $j + 1`
        while [ $j -lt $num ]
        do
            res=`echo "$res/${a[$j]}" | bc -l`
            j=$(($j+1))
        done

elif [[ $operat = "-" ]]
    then   
        j=0
        res=${a[$j]}
        j=`expr $j + 1`
        while [ $j -lt $num ]
        do
            res=$(($res-${a[$j]}))
            j=$(($j+1))
        done

fi

#echo $res
printf '%.4f\n' $res

